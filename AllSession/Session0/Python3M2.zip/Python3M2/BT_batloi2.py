import re
import datetime

date = input("Nhập ngày,tháng,năm: ")
try:
    datetime.datetime.strptime(date, "%d/%m/%Y")
    print("Date hợp lệ")
except:
    print("Date không hợp lệ")