try:
    with open('text.txt','r') as f:
        print(f.read())
#w: write
#r: read
#a: (append) add, thêm vào
except FileNotFoundError:
    print("Không tìm thấy file")
except IOError:
    print("Lỗi đọc file")