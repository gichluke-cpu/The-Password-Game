import re

pattern = r'^(?:\+84|0)(3|5|7|8|9)\d{8}$'

while True:
    phone_number = input("Nhập số điện thoại: ")
    if re.match(pattern, phone_number):
        print("Số điện thoại hợp lệ")
        break
    else:
        print("Số điện thoại không hợp lệ, mời bạn nhập lại")